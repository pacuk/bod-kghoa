        </main>
    </div>

    <footer> 
        <div class="bg-yellow text-center py-3">
            <p class="copyright text-black-50">&copy;2025. Kensington Grove Homeowners Association, Board of Directors Portal. All rights reserved.</p>
        </div>
    </footer>
    
    <?php wp_footer(); ?>

</body>
</html>